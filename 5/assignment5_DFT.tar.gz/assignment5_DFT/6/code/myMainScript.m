%% MyMainScript
tic;
% hyperparameters
sigma = 20; 
p = 7;
L = 200;
window = 31;

% Get image and make it noisy
im = double(imread('../data/barbara256.png'));
im_noisy = im + sigma*randn(size(im));
im2 = myPCADenoising1(im_noisy, sigma, p);
im3 = myPCADenoising2(im_noisy, sigma, p, L, window);

% Show all figures
figure; imagesc(im); colormap(gray); title('Real image');
figure; imagesc(im_noisy); colormap(gray); title('Noisy image');
figure; imagesc(im2); colormap(gray); title('Denoised image');
figure; imagesc(im3); colormap(gray); title('Denoised image using window');

toc;
